from setuptools import setup

setup(
    name='lyrics_custom_code',
    version='0.1',
    scripts=['predictor.py', 'preprocess.py'])